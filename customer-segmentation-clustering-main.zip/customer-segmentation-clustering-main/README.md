# Customer Segmentation using K-Means Clustering

This project explores customer segmentation using unsupervised machine learning techniques. The objective is to group customers into clusters based on their purchasing behavior and demographic characteristics using the K-Means algorithm.

## 📊 Project Overview

The notebook includes:

- Data cleaning and preprocessing
- Exploratory Data Analysis (EDA)
- Feature scaling
- Elbow method to determine the optimal number of clusters
- K-Means clustering algorithm
- Cluster visualization using PCA

## 🧰 Technologies Used

- Python 3.x
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn

📌 Notes
The dataset used is synthetic/customer behavioral data (Mall_Customers.csv or equivalent).

PCA is used for dimensionality reduction for visualization.

📜 License
This project is licensed under the MIT License - see the LICENSE file for details.

---

### 📦 `requirements.txt`

```txt
pandas
numpy
matplotlib
seaborn
scikit-learn
jupyter